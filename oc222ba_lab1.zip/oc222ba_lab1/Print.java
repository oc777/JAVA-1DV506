/**
 * 
 */
package oc222ba_lab1;

/**
 * @author olgachristensen
 *
 */
public class Print {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		System.out.println("Knowledge is power!");
		System.out.println("Knowledge\n is\n power!");
		System.out.println(
				  "=======================\n"
				+ "|                     |\n"
				+ "| Knowledge is power! |\n"
				+ "|                     |\n"
				+ "=======================");
	}

}
